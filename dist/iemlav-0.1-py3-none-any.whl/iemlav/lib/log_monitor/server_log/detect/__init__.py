"""Summary.attacks"""
from .attacks import ddos
from .attacks import lfi
from .attacks import sqli
from .attacks import web_shell
from .attacks import xss
from .recon import fuzzer
from .recon import port_scan
from .recon import spider
