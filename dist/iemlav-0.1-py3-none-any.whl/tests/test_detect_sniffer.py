# -*- coding: utf-8 -*-
import unittest
from iemlav.lib.log_monitor.system_log.detect_sniffer import DetSniffer
from iemlav.logger import IemlAVLogger

try:
    # if python 3.x.x
    from unittest.mock import patch
except ImportError:  # python 2.x.x
    from mock import patch


class TestDetSniffer(unittest.TestCase):
    """
    Test class for DetSniffer.
    """

    def setUp(self):
        """
        Setup class for DetSniffer..
        """
        self.os = "debian"

    @patch.object(IemlAVLogger, "log")
    @patch('iemlav.lib.log_monitor.system_log.detect_sniffer.utils')
    def test_parse_log_file(self, mock_utils, mock_log):
        """
        Test parse_log_file.
        """
        mock_utils.categorize_os.return_value = self.os
        # Create DetSniffer object
        self.det_sniff = DetSniffer()
        mock_utils.open_file.return_value = ["Jun  4 11:10:31 adam kernel: [11.770669] \
                                             device virbr0-nic entered promiscuous mode"]
        self.det_sniff.parse_log_file()
        mock_log.assert_called_with('Possible malicious sniffer detected virbr0-nic',
                                    logtype='warning')
